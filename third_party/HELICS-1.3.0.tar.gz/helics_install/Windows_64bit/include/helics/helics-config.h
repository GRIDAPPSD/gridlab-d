/*
Copyright � 2017-2018,
Battelle Memorial Institute; Lawrence Livermore National Security, LLC; Alliance for Sustainable Energy, LLC
All rights reserved. See LICENSE file and DISCLAIMER for more details.
*/
#pragma once

#include "compiler-config.h"

#define HELICS_HAVE_MPI 0

#define HELICS_HAVE_ZEROMQ 1

/* #undef DISABLE_TCP_CORE */

/* #undef DISABLE_LOGGING */
/* #undef DISABLE_TRACE_LOGGING */
/* #undef DISABLE_DEBUG_LOGGING */

/* #undef BOOST_STATIC */

/* #undef HELICS_USE_PICOSECOND_TIME */

#define BOOST_VERSION_LEVEL 2

#define HELICS_VERSION_MAJOR 1
#define HELICS_VERSION_MINOR 3
#define HELICS_VERSION_PATCH 0
#define HELICS_VERSION 1.3.0
#define HELICS_VERSION_BUILD ""
#define HELICS_VERSION_STRING "1.3.0 (07-31-18)"
#define HELICS_DATE "07-31-18"

